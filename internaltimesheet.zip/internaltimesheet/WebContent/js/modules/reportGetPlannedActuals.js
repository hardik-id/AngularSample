/**
 * 
 */

var app = angular.module('reportPlannedActual-module', [ 'myapp-http-request' ,'project-module', 'datatables' ,'user-module' ]);

app.controller('reportPlannedActualController',function($scope,$window, projectService,userService, DTOptionsBuilder, DTColumnBuilder) {
	this.projects = [];
	this.showLoadingImage = false;
	this.currentTab=3;
	this.loadProjects = function() {
		projectService.getCallOut(this.setProjectList);
	};

	this.setProjectList = function(data) {
		$scope.rptPACtrl.projects = data;
	};

	 this.loadUsers = function() {
			userService.getCallOut(this.setUserList);
		};
		this.setUserList = function(data) {
			$scope.rptPACtrl.users = data;
		};
	
	this.reloadData = function() {
		this.showLoadingImage = true;
		if(this.currentTab===1){
			$scope.dtOptions.reloadData();
		}else if(this.currentTab===2){
			$scope.dtOptionsResource.reloadData();
		}else if(this.currentTab===3){
			getPivotTable();
		};
        this.showLoadingImage = false;
    };
   
    
    this.showDT = function(selected){
    	if(this.currentTab===selected){
    		return true;
    	}
    	else {
    		return false;
    	}
    };
    this.setDT = function(selected){
    	this.currentTab=selected;
    };
    
	$scope.dtOptions = DTOptionsBuilder.fromSource($window.baseURL+'reports/plannedactual')
	.withFnServerData(function (sSource, aoData, fnCallback, oSettings) {
            oSettings.jqXHR = $.ajax( {
                'dataType': 'json',
                'contentType': 'application/json',
                'type': 'POST',
                'url': sSource,
                'data': JSON.stringify({"startDate":Date.parse($scope.startDateM),"endDate":Date.parse($scope.endDateM),"projectUUID":angular.element('#comboboxProject').val()}),
                'success': fnCallback
            });
	}).withTableTools('https://github.com/DataTables/TableTools/raw/master/swf/copy_csv_xls_pdf.swf')
    .withTableToolsButtons([
                            'copy',
                            'print', {
                                'sExtends': 'collection',
                                'sButtonText': 'Save',
                                'aButtons': ['csv', 'xls', 'pdf']
                            }
                        ])
		.withPaginationType('full_numbers')
		.withOption('order', [[2, 'desc']])
		.withOption('rowCallback', function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
			//Unbind first in order to avoid any duplicate handler (see https://github.com/l-lin/angular-datatables/issues/87)
			$('td', nRow).unbind('click');
	        $('td', nRow).bind('click', function() {
	        	$scope.$apply(function() {
	        		/* 
	        		Even Handler
	        		$scope.someClickHandler(aData);
	        		*/
	        	});
	        });
	        return nRow;
		});
	
	$scope.dtColumns = [
	        DTColumnBuilder.newColumn('ProjectName').withTitle('Project Name'),
	        DTColumnBuilder.newColumn('ProjectStatus').withTitle('Project Status'),
	        DTColumnBuilder.newColumn('Planned').withTitle('Planned Hours'),
	        DTColumnBuilder.newColumn('Actuals').withTitle('Actual Hours'),
	        
	    ];
    
    	$scope.dtOptionsResource = DTOptionsBuilder.fromSource($window.baseURL+'reports/taskdatadump')
    	.withFnServerData(function (sSource, aoData, fnCallback, oSettings) {
                oSettings.jqXHR = $.ajax( {
                    'dataType': 'json',
                    'contentType': 'application/json',
                    'type': 'POST',
                    'url': sSource,
                    'data': JSON.stringify({"startDate":Date.parse($scope.startDateM),"endDate":Date.parse($scope.endDateM),"userUUID":"26b077d6-b5e8-4a42-883f-b216ed216e27"}),
                    'success': fnCallback
                });
    	}).withTableTools('https://github.com/DataTables/TableTools/raw/master/swf/copy_csv_xls_pdf.swf')
        .withTableToolsButtons([
                                'copy',
                                'print', {
                                    'sExtends': 'collection',
                                    'sButtonText': 'Save',
                                    'aButtons': ['csv', 'xls', 'pdf']
                                }
                            ])
    		.withPaginationType('full_numbers')
    		.withOption('rowCallback', function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
    			//Unbind first in order to avoid any duplicate handler (see https://github.com/l-lin/angular-datatables/issues/87)
    			$('td', nRow).unbind('click');
    	        $('td', nRow).bind('click', function() {
    	        	$scope.$apply(function() {
    	        		/* 
    	        		Even Handler
    	        		$scope.someClickHandler(aData);
    	        		*/
    	        	});
    	        });
    	        return nRow;
    		});

    	$scope.dtColumnsResource = [
    	        DTColumnBuilder.newColumn('user').withTitle('Name'),
    	        DTColumnBuilder.newColumn('taskDate').withTitle('Task Date'),
    	        DTColumnBuilder.newColumn('projectName').withTitle('Project Name'),
    	        DTColumnBuilder.newColumn('taskName').withTitle('Task Name'),
    	        DTColumnBuilder.newColumn('taskDetail').withTitle('Task Detail'),
    	        DTColumnBuilder.newColumn('comments').withTitle('Comments'),
    	        DTColumnBuilder.newColumn('hours').withTitle('Hours')
    	        
    	    ];
   //     };
});