/**
 * 
 */
var app = angular.module('user-module', [ 'myapp-http-request','errorHandler-module']);

app.service('userService', function(MyRequests,errorHandlerService) {
	this.error = function(error) {
		console.log(JSON.stringify(error));
//		errorHandlerService.processError(error);
	};
	this.getCallOut = function(callback) {
		return MyRequests.authentifiedRequest('get','user/list', '', callback,this.error);
	};
});