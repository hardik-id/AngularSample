/**
 * 
 */

var app = angular.module('report-module', [ 'myapp-http-request' ,'user-module' ]);

app.controller('reportController',function($scope,$window, userService, DTOptionsBuilder, DTColumnBuilder) {
	this.users = [];
	this.showLoadingImage = false;
	this.loadUsers = function() {
		userService.getCallOut(this.setUserList);
	};
/*	this.getDataUserDateFilter = function() {
		var startDate = Date.parse($scope.startDateM);
		var endDate = Date.parse($scope.endDateM);
		var userIdentifier = angular.element('#user').val();
		this.showLoadingImage = false;
	};*/
	this.setUserList = function(data) {
		$scope.rptCtrl.users = data;
	};
	
	this.reloadData = function() {
		this.showLoadingImage = true;
        $scope.dtOptions.reloadData();
        this.showLoadingImage = false;
    };
	$scope.dtOptions = DTOptionsBuilder.fromSource($window.baseURL+'reports/taskdatadump')
	.withFnServerData(function (sSource, aoData, fnCallback, oSettings) {
            oSettings.jqXHR = $.ajax( {
                'dataType': 'json',
                'contentType': 'application/json',
                'type': 'POST',
                'url': sSource,
                'data': JSON.stringify({"startDate":Date.parse($scope.startDateM),"endDate":Date.parse($scope.endDateM),"userUUID":"26b077d6-b5e8-4a42-883f-b216ed216e27"}),
                'success': fnCallback
            });
	}).withTableTools('https://github.com/DataTables/TableTools/raw/master/swf/copy_csv_xls_pdf.swf')
    .withTableToolsButtons([
                            'copy',
                            'print', {
                                'sExtends': 'collection',
                                'sButtonText': 'Save',
                                'aButtons': ['csv', 'xls', 'pdf']
                            }
                        ])
		.withPaginationType('full_numbers')
		.withOption('rowCallback', function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
			//Unbind first in order to avoid any duplicate handler (see https://github.com/l-lin/angular-datatables/issues/87)
			$('td', nRow).unbind('click');
	        $('td', nRow).bind('click', function() {
	        	$scope.$apply(function() {
	        		$scope.someClickHandler(aData);
	        	});
	        });
	        return nRow;
		});
	
	$scope.dtColumns = [
	        DTColumnBuilder.newColumn('user').withTitle('Name'),
	        DTColumnBuilder.newColumn('taskDate').withTitle('Task Date'),
	        DTColumnBuilder.newColumn('projectName').withTitle('Project Name'),
	        DTColumnBuilder.newColumn('taskName').withTitle('Task Name'),
	        DTColumnBuilder.newColumn('taskDetail').withTitle('Task Detail'),
	        DTColumnBuilder.newColumn('comments').withTitle('Comments'),
	        DTColumnBuilder.newColumn('hours').withTitle('Hours')
	        
	    ];
});