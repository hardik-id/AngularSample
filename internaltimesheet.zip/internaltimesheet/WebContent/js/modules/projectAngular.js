/**
 * 
 */
var app = angular.module('project-module', [ 'myapp-http-request','errorHandler-module']);

app.service('projectService', function(MyRequests,errorHandlerService) {
	this.error = function(error) {
		console.log(JSON.stringify(error));
//		errorHandlerService.processError(error);
	};
	this.getCallOut = function(callback) {
		var data={q : "all",column : "all"};
		return MyRequests.authentifiedRequest('GET','user/project/search', data, callback,this.error);
	};
});