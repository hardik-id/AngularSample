/**
 * 
 */

var app = angular.module('tasks-module', [ 'myapp-http-request' ,'user-module' ]);

app.controller('tasksController',function($scope) {


	$scope.selectedColour = $scope.colours[2]; // red.

	$scope.colourChanged = function (value) {
	    var colourName = value ? value.name : "none";
	    $scope.message = "ac-change event fired for colour. New colour: " + colourName;
	    $scope.$digest();
	};

	$scope.colours = [
	    { name: 'black', id: 0 },
	    { name: 'white', id: 1 },
	    { name: 'red', id: 2 }];
	
});









