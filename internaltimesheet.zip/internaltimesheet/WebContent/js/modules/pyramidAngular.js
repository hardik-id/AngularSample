/**
 * 
 */

var app = angular.module('pyramid-module', []);

app.controller('pyramidController',function($scope,$window) {
    this.TotalMembers = 0;
    
    this.Leads = 0;
    this.SSEs = 0;
    this.SEs = 0;
    this.ASEs = 0;
    
    this.LeadWidth = 100;
    this.SSEWidth = 200;
    this.SEWidth = 400;
    this.ASEWidth = 800;
    this.widthMultiplier = 100;
    
    this.calculate = function() {
        alert("Total Budget : " + $scope.TotalBudget);
        alert("Total Rate : " + $scope.BRRate);
        this.TotalMembers = $scope.TotalBudget / $scope.BRRate;
        alert("Total Members : "+this.TotalMembers);
        alert("Total SSEFactor : "+$scope.SSEFactor);
        alert("Total SEFactor : "+$scope.SEFactor);
        alert("Total ASEFactor : "+$scope.ASEFactor);
        alert("Total :"+(1+parseInt($scope.SSEFactor)+parseInt($scope.SEFactor)+parseInt($scope.ASEFactor)));
        this.Leads = this.TotalMembers / (1+parseInt($scope.SSEFactor)+parseInt($scope.SEFactor)+parseInt($scope.ASEFactor));
        alert("Leads "+this.Leads);
        this.SSEs = toFixed(this.Leads * $scope.SSEFactor);
        this.SEs = toFixed(this.Leads * $scope.SEFactor);
        this.ASEs = toFixed(this.Leads * $scope.ASEFactor);
        this.Leads = toFixed(this.Leads);
        
        // Set Width of each Div
        this.SSEWidth = parseInt($scope.SSEFactor) * this.widthMultiplier;
        this.SEWidth = parseInt($scope.SEFactor) * this.widthMultiplier;
        this.ASEWidth = parseInt($scope.ASEFactor) * this.widthMultiplier;

    }
    

});