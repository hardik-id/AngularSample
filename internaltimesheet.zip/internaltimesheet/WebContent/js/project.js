javaRest.project = {};


/**
 * Create a Project
 */

javaRest.project.create = function (projectName, projectType, projectStatus, startDate, endDate,wbsCode, plannedHours, callback) {


  javaRest.post(
		  baseURL+ 'user/project',
    {
        "projectName" : projectName,
        "projectType" : projectType,
        "projectStatus" : projectStatus,
        "startDate" : startDate,
        "endDate" : endDate,
        "wbsCode" : wbsCode,
        "plannedHours" : plannedHours,
        "createdByUUID":javaRest.cookie.get('userId')
      
    },
    function (response) {
      callback();
    },
    function(jqXHR, textStatus) {
      console.log(jqXHR);
      callback(jqXHR);
    });

};

javaRest.project.update = function (pid,projectName, projectType, projectStatus, startDate, endDate,wbsCode,plannedHours, callback) {


	  javaRest.put(
			  baseURL+ 'user/project/'+pid,
	    {
	        "projectName" : projectName,
	        "projectType" : projectType,
	        "projectStatus" : projectStatus,
	        "startDate" : startDate,
	        "endDate" : endDate,
	        "wbsCode" : wbsCode,
	        "plannedHours" : plannedHours,
	        "createdByUUID":javaRest.cookie.get('userId')
	      
	    },
	    function (response) {
	      callback();
	    },
	    function(jqXHR, textStatus) {
	      console.log(jqXHR);
	      callback(jqXHR);
	    });

};


