javaRest.report = {};


/**
 * Create a report
 */

javaRest.report.getUser = function (startDate, endDate, callback) {


  javaRest.post(
		  baseURL+ 'reports/user',
    {
        "startDate" : startDate,
        "endDate" : endDate,
        "userUUID": javaRest.cookie.get('userId')
        //"createdByUUID":javaRest.cookie.get('userId')
      
    },
    function (response) {
      callback(response);
    },
    function(jqXHR, textStatus) {
      console.log(jqXHR);
      callback(jqXHR);
    });

};

javaRest.report.update = function (pid,reportName, reportType, startDate, endDate, callback) {


	  javaRest.putwo(
			  baseURL+ 'user/report/'+pid,
	    {
	        "reportName" : reportName,
	        "reportType" : reportType,
	        "startDate" : startDate,
	        "endDate" : endDate,
	        "createdByUUID":javaRest.cookie.get('userId')
	      
	    },
	    function (response) {
	      callback();
	    },
	    function(jqXHR, textStatus) {
	      console.log(jqXHR);
	      callback(jqXHR);
	    });

};
