/**
 * 
 */

var app = angular.module('errorHandler-module', []);

app.service('errorHandlerService', function($location) {
	this.processError = function(error) {
		window.location ='index.html';
	};
});