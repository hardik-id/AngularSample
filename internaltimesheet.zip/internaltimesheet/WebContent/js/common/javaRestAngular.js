/**
 *
 */

var javaRestAngularModule = angular.module('myapp-http-request',['ngCookies']);

javaRestAngularModule.service('MyRequests', ['$http','$window', '$cookieStore','$cookies',function($http,$window, $cookieStore,$cookies){
		this.request= function(method, url, data, okCallback, koCallback){
            $http({
                method: method,
                url: $window.baseURL+url,
                data: data
            }).success(okCallback).error(koCallback);
        };
        this.authentifiedRequest = function(method, url, data, okCallback, koCallback){
            $http({
                method: method,
                url: $window.baseURL+url,
                data: data,
                headers: {'Authorization': $cookies['token']}
            }).success(okCallback).error(koCallback);
        };
}]);
getDate{
    return new Date(this.date) ;
}


Date d = new Today();
Employee e = new Employeed("1","Hardik",d);
Date b = e.get(Date);
b.setDate(tomorrow)
sout(emplye.d);
d.setdate(tomorow);
sout(eno,y,date)