/**
 * 
 */

var app = angular.module("TimeSheet",["report-module","datatables"]);

//app.run(['$http','$cookieStore', function($http,$cookieStore) {
//    $http.defaults.headers.common.Authorization = $cookieStore.get('token');
//}]);