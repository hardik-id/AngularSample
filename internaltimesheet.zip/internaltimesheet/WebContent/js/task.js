javaRest.task = {}


/**
 * Create a Task
 */

javaRest.task.create = function (projectName,taskType, taskDate, taskHours,taskDetail,taskComments, callback) {

  javaRest.post(
		  baseURL+ 'user/task',
		  {
			  "projectUUID":projectName,
			  "taskDetail":taskDetail,
			  "taskTypeUUID":taskType,
			  "hours":taskHours,
			  "taskDate":taskDate,
			  "comments":taskComments,
			  "createdByUUID":javaRest.cookie.get('userId')
		  },
    function (response) {
      callback();
    },
    function(jqXHR, textStatus) {
      console.log(jqXHR);
      callback(jqXHR);
    });

};

javaRest.task.update = function (taskId,projectName,taskType, taskDate, taskHours,taskDetail,taskComments, callback) {
	  javaRest.putwo(
			  baseURL+ 'user/task/'+taskId,
			  {
				  "projectUUID":projectName,
				  "taskDetail":taskDetail,
				  "taskTypeUUID":taskType,
				  "hours":taskHours,
				  "taskDate":taskDate,
				  "comments":taskComments,
				  "createdByUUID":javaRest.cookie.get('userId')
			  },
	    function (response) {
	      callback();
	    },
	    function(jqXHR, textStatus) {
	      console.log(jqXHR);
	      callback(jqXHR);
	    });
};
